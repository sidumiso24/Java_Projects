// Main.java
// Written by: Sidumiso Debbie Mabaso
// Date: 10 June 2020
// Function: this program is an extended program of the Poised Projects with specifications given by the client.


import java.util.*;
import java.util.Date;
import java.text.*;
import java.io.*;
import java.sql.*;
import java.time.*;

public class Main {

	public static void main(String[] args) {
		
		ResultSet results;
		
		try {
			
			Connection connection  = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?useSSL=false", "otheruser", "SIKHUMBUZOMEMORY@MABASO11!!**!!");
			
			Statement statement = connection.createStatement();
			
			int rowsAffected = 0;
			
			// creating an Array List object called 'projectObject'
			ArrayList<PoisedProject> projectObject = getDataFromPoise();
			
			// creating a Scanner object called 'scan'
			Scanner scan = new Scanner(System.in);
			
			// declaring a boolean variable called 'control'
			Boolean control = true;
			
			// a while loop that executes the following
			while (control) {
				
				// asks for user's input and input is stored in a variable called 'option'
				// and is change to lower case in a variable called 'optionLower'
				System.out.println("Please choose the following options:\n\n a - add a project\n e - edit existing project\n v - view incomplete tasks\n o - Overdue projects \n np - all poised projects");
				
				String option = scan.nextLine();
				
				String optionLower = option.toLowerCase();
				
				try {
					
					// if the user choose the option 'a' (add a project)
					// the client's, the architect's, the contractor and the project details is required from the user
					// the details are then stored and displayed to the user
					// which then is written to a text file
					if(optionLower.equals("a")) {
						
				        
						System.out.print("\nPlease enter the client's details:\n");
						
				        People client = new People();
				
				        Scanner clientInput = new Scanner(System.in);
				        
				        System.out.print("\nName: ");
				        
				        client.setName(clientInput.nextLine());
				    	
				        clientInput = new Scanner(System.in);
				        
				        System.out.print("\nSurname: ");
				        client.setClientSurname(clientInput.nextLine());
			        
				        clientInput = new Scanner(System.in);
				        System.out.print("\nTelephone/phone number: ");
				        
				        try {
					    	
					    	String input = clientInput.next();
					    	
					    	for(int count = 0; count < input.length(); count++) {
					    	
					    		if (!Character.isDigit(input.charAt(count))) {
					    		
					    			throw new Exception();
					    	}
					    }
					    
					    	Long.parseLong(input);
					    	
					    	if (input.length() != 10) {
					    		
					    		throw new NumberFormatException();
					    	}
					    	
				        	client.setTelNum(input);
						}
				        catch  (Exception E) { 
					    	
				        	System.out.print("Invalid information\n");
				        	
				        	boolean invalidNum = true;
				        	
				        	do {
				        		
					    		System.out.println("You have entered an incorrect telephone/phone number.");
				    		
				        		System.out.print("Telephone/phone number: ");
				        		
				        		clientInput = new Scanner(System.in);
				        		
				        		Boolean hasNext = clientInput.hasNext();
				        		
				        		String input = clientInput.next();
				        		
				        		if (hasNext) {
				        			
				        			client.setTelNum(input);
				        			
				        			invalidNum = false;
				        		}
				        		
				        		if  (input.length() != 10) {
			        			
				        			invalidNum = true;
				        		}
				        		
				        		for(int counter = 0; counter < input.length(); counter++) {
							    	
							    	if (!Character.isDigit(input.charAt(counter))) {
							    		
							    		invalidNum = true;
							    		
							    		continue;
							    	}
							    }
				        		
				        	}
				        	while(invalidNum);
					    }
				        
				        String clientTelNum = client.getPersonsTelNum();
				        
				        clientInput = new Scanner(System.in);
				        
				        System.out.print("\nEmail Address: ");
				        
				        client.setEmailAddress(clientInput.nextLine());
			      
				        clientInput = new Scanner(System.in);
				        
				        System.out.print("\nAddress: ");
				        
				        client.setAddress(clientInput.nextLine());
				
				        System.out.print("\nPlease enter the Architect's details:\n");
				        
				        People architect = new People();
				       
				        Scanner architectInput = new Scanner(System.in);
				        
				        System.out.print("\nName: ");
				        
				        architect.setName(architectInput.nextLine());
		
				        
				        architectInput = new Scanner(System.in);
				        
				        System.out.print("\nSurname: ");
				        
				        architect.setClientSurname(architectInput.nextLine());
		
				        architectInput = new Scanner(System.in);
				        
				        System.out.print("\nTelephone/phone number: ");
				        
				        try {
				        	
				        	String input = architectInput.next();
				        	
				        	for(int count = 0; count < input.length(); count++) {
						    	
						    	if (!Character.isDigit(input.charAt(count))) {
						    		
						    		throw new Exception();
						    	}
						    }
				        	
					    	Long.parseLong(input);
					    	
					    	if (input.length()!=10) {
					    		
					    		throw new NumberFormatException();
					    	}
					    	
				        	architect.setTelNum(input);
				        }
				        
				        catch  (Exception error) { 
					    	
				        	System.out.print("Invalid information.\n");
				        	
				        	boolean invalidNum = true;
				        	
				        	do {
				        		
					    		System.out.println("You have entered an incorrect telephone/phone number.");
					    		
				        		System.out.print("Telephone/phone number: ");
				        		
				        		architectInput = new Scanner(System.in);
				        		
				        		Boolean hasNext = architectInput.hasNext();
				        		
				        		String input = architectInput.next();
			        		
				        		if (hasNext) {
				        			
				        			architect.setTelNum(input);
				        			
				        			invalidNum = false;
				        		}
				        		if  (input.length() != 10) {
				        			
				        			invalidNum = true;
				        		}
				        		
				        		 for(int counter = 0; counter < input.length(); counter++) {
								    	
								    	if (!Character.isDigit(input.charAt(counter))) {
								    		
								    		invalidNum = true;
								    		
								    		continue;
								    	}
				        		 }
				     
				        		}
				        	
				        	while(invalidNum);
					    }
				        
				        String architectTelNum = architect.getPersonsTelNum();
				        
				        architectInput = new Scanner(System.in);
				        
				        System.out.print("\nEmail Address: ");
			        
				        architect.setEmailAddress(architectInput.nextLine());
		
				       
				        architectInput = new Scanner(System.in);
				        
				        System.out.print("\nAddress: ");
				        
				        architect.setAddress(architectInput.nextLine());
		
				        System.out.print("\nPlease enter the contractor's details:\n");
				        
				        People contractor = new People();
				        
				        
				        Scanner contractorInput = new Scanner(System.in);
				        
				        System.out.print("\nName: ");
				        
				        contractor.setName(contractorInput.nextLine());

				       
				        contractorInput = new Scanner(System.in);
				        
				        System.out.print("\nSurname: ");
				        
				        contractor.setClientSurname(contractorInput.nextLine());
		
				        
				        contractorInput = new Scanner(System.in);
				        
				        System.out.print("\nTelephone/phone number: ");
				        
				        try {
					    	
					    	String input = contractorInput.nextLine();
					    	
			                for(int count = 0; count < input.length(); count++) {
						    	
						    	if (!Character.isDigit(input.charAt(count))) {
						    		
						    		throw new Exception();
						    	}
						    	
			                }
			                
					    	
					    	if (input.length() != 10) {
					    		
					    	throw new NumberFormatException();
					    	}
				        
				        	contractor.setTelNum(input);
				        	
					    }
				        
				        catch (Exception error) {
					    	
					    	System.out.print("Invalid information\n");
					    	
					    	boolean invalidNum = true;
					    	do {
					    		System.out.println("You have entered an incorrect telephone/phone number.");
					    		
				        		System.out.print("Telephone/phone number: ");
				        		
				        		contractorInput = new Scanner(System.in);
				        		
				        		Boolean hasNext = contractorInput.hasNext();
				        		
				        		String input = contractorInput.next();
				        		
				        		if (hasNext) {
				        			
				        			contractor.setTelNum(input);
				        			 
				        			invalidNum = false;
				        		}
				        	
				        		if  (input.length() != 10) {
				        			
				        			invalidNum = true;
				        		}
				        		
				        		 for(int counter = 0; counter < input.length(); counter++) {
								    	
								    	if (!Character.isDigit(input.charAt(counter))) {
								    		
								    		invalidNum = true;
								    		
								    		continue;
								    	}
								    }
					    	} 
					    	while (invalidNum);
						  }
				        
				        contractorInput = new Scanner(System.in);
				        
				        System.out.print("\nEmail Address: ");
				        
				        contractor.setEmailAddress(contractorInput.nextLine());
				        
				        contractorInput = new Scanner(System.in);
				        
				        System.out.print("\nAddress: ");
				        
				        contractor.setAddress(contractorInput.nextLine());
				        
				        
				        System.out.print("\nPlease enter the project details: \n");
				        
				        PoisedProject project = new PoisedProject(rowsAffected, architectTelNum, architectTelNum, architectTelNum, rowsAffected, rowsAffected, rowsAffected, architectTelNum, architectTelNum, contractor, contractor, contractor);
				        
				        Scanner projectInput = new Scanner(System.in);
	 
				        projectInput = new Scanner(System.in);
				        
				        System.out.print("\nProject Number: ");
				        
				        try {
				        	
				        	project.setProjectNum(projectInput.nextInt());
				        }
				        
				        catch (Exception e) {
				        	
				        	boolean invalidNum = true;
				        	
				        	do {
				        		
				        		System.out.println("You have entered an incorrect project number.");
				        		
				        		System.out.print("Project Number: ");
				        		
				        		projectInput = new Scanner(System.in);
				        		
				        		if(projectInput.hasNextInt()) {
				        			
				        			project.setProjectNum(projectInput.nextInt());
				        			
				        			invalidNum = false;
				        		}
				        		
				        		
				        	}
				        	while(invalidNum);
				        	
				        	project.setProjectNum(0);
				        }
				        
				        projectInput = new Scanner(System.in);
				        
				        System.out.print("\nThe type of building (e.g. house, apartment, etc): ");
				        
				        project.setBuildingStructure(projectInput.nextLine());

				        projectInput = new Scanner(System.in);
				        
				        System.out.print("\nName of the project: ");
				        
				        if (projectInput.nextLine().equals("")) {
				        	
				        	String projectName = project.getBuildingStructure() + " " + client.getPersonsSurname();
					        
				        	project.setProjectName(projectName);
				        
				        }
				        
				        else {
				        	
				        	project.setProjectName(projectInput.nextLine());
				        }
		
				        projectInput = new Scanner(System.in);
				        
				        System.out.print("\nAddress: ");
				        
				        project.setAddress(projectInput.nextLine());

				        projectInput = new Scanner(System.in);
				        
				        System.out.print("\nERF Number: ");
				        
				        try {
				        	
				        	project.setERFnum(projectInput.nextInt());
				        }
				        
				        catch (Exception E) {
				        	
				        	boolean invalidERFnum = true;
				        	do {
				        		
				        		System.out.println("You have entered an incorrect ERF number.");
				        		
				        		System.out.println("ERF Number: ");
				        	
				        		projectInput = new Scanner(System.in);
				        	
				        		if(projectInput.hasNextInt()) {
				        			
				        			invalidERFnum = false;
				        		
				        			project.setERFnum(projectInput.nextInt());
				        		}
				        		
				        	}
				        	
				        	while(invalidERFnum);
				        }
				        
				        projectInput = new Scanner(System.in);
				        
				        System.out.print("\nProject Fee: R ");
				        
				        try {
				        	
				        	project.setTotProjectFee(projectInput.nextDouble());
				        	
				        }
				        catch (Exception E) {
				        	
				        	System.out.println("You have entered invalid digits.");
				        	
				        	project.setTotProjectFee(0);
				        	
				        }

				        projectInput = new Scanner(System.in);
				        
				        System.out.print("\nAmount paid: R ");
				        
				        try {
				        	project.setPaidAmount(projectInput.nextDouble());
				        	
				        }
				        catch (Exception E) {
				        	
				        	System.out.println("Incorrect input.");
				        	
				        	project.setPaidAmount(0);
				        
				        }
				        
				        project.setCompletion("No");

				        projectInput = new Scanner(System.in);
				        
				        System.out.print("\nProject Due Date (dd-MM-yyyy): ");
				        
				        project.setProjectDueDate(projectInput.nextLine());

				        project.setArchitect(architect);
				
				        project.setClient(client);
		
				        project.setContractor(contractor);
				        
				        String clientQuery = "INSERT INTO PEOPLE_TABLE VALUES('"+ client.getPersonsName() + "', '" + client.getPersonsSurname() + "', '" + client.getPersonsTelNum() + "', '" + client.getPersonsEmailAddress() + "', '" + client.getPersonsAddress() + "');";
				        rowsAffected = statement.executeUpdate(clientQuery);
				        System.out.println("Query complete, " + rowsAffected + " rows added.");
				        
				        String architectQuery = "INSERT INTO PEOPLE_TABLE VALUES('" + architect.getPersonsName() + "', '" + architect.getPersonsSurname() + "', '" + architect.getPersonsTelNum() + "', '" + architect.getPersonsEmailAddress() + "', '" + architect.getPersonsAddress() + "');";
				        rowsAffected = statement.executeUpdate(architectQuery);
				        System.out.println("Query complete, " + rowsAffected + " rows added.");
				        
				        String contractorQuery = "INSERT INTO PEOPLE_TABLE VALUES('" + contractor.getPersonsName() + "', '" + contractor.getPersonsSurname() + "', '" + contractor.getPersonsTelNum() + "', '" + contractor.getPersonsEmailAddress() + "', '" + contractor.getPersonsAddress() + "');";
				        rowsAffected = statement.executeUpdate(contractorQuery);
				        System.out.println("Query complete, " + rowsAffected + " rows added.");
				        
				        String projectQuery = "INSERT INTO PROJECT_TABLE VALUES(" + project.getProjectNum() + "', '" + project.getProjectName() + "', '" + project.getBuildingStructure() + "', '" + project.getAddress() + "', '" + project.getERFnum() + "', '" + project.getTotProjectFee() + "', '" + project.getPaidAmount() + "', '" + project.getCompletion() + "', '" + project.getProjectDueDate() + "', '" + project.getDateCompleted() + "', '" + client.getPersonsName() + "', '" + client.getPersonsSurname() + "', '" + architect.getPersonsName() + "', '" + architect.getPersonsSurname() + "', '" + contractor.getPersonsName() + "', '" + contractor.getPersonsSurname() + "');";
				        rowsAffected = statement.executeUpdate(projectQuery);
				        System.out.println("Query complete, " + rowsAffected + " rows added.");
		
				        System.out.println("\nTHE PROJECT DETAILS\n");
				        
				        try {
				        	
				        	results = statement.executeQuery("SELECT Project_Number, Project_Name, Building_Type, Project_Address, ERF_Number, Project_Fee, Paid_Amount, Project_Completed, Project_Duedate, Completion_Date, FROM PROJECT_TABLE WHERE Project_Number =" + project.getProjectNum() + "");
				        	
				        	while (results.next()) {
				        		
				        		System.out.println("Project Number		" + results.getInt("Project_Number") +
				        				"\nProject Name 		" + results.getString("Project_Name") +
				        				"\nBuilding Type		" + results.getString("Building_Type") + 
				        				"\nProject Address		" + results.getString("Project_Address") + 
				        				"\nERF Number		" + results.getInt("ERF_Number") +
				        				"\nProject Fee		" + results.getDouble("Project_Fee") +
				        				"\nAmount Paid		" + results.getDouble("Amount_Paid") +
				        				"\nProject Due date		" + results.getString("Project_Duedate") +
				        				"\nProject Completion		" + results.getString("Project_Completed") + 
				        				"\nCompletion Date		" + results.getString("Completion_Date"));
				  
				        	}
				        }
				        
				        catch (SQLException ex) {
				        	ex.printStackTrace();
				        }
		
				        System.out.println("\nTHE CLIENT'S DETAILS\n");
				        
				        try {
				        	
				        	results = statement.executeQuery("SELECT Name, Surname, Telephone, Email_Address, Physical_Address FROM PEOPLE_TABLE WHERE Name = '" + client.getPersonsName() + "' AND Surname = '" + client.getPersonsSurname() + "'");
				        	
				        	while (results.next()) {
				        		
				        		System.out.println("Name		" + results.getString("Name") + 
				        				"\nSurname		" + results.getString("Surname") + 
				        				"\nTelephne		" + results.getString("Telephone") + 
				        				"\nEmail Address	" + results.getString("Email_Address") + 
				        				"\nPhysical Address		" + results.getString("Physical_Address"));

				        	}
				        }
				        
				        catch (SQLException ex) {
				        	ex.printStackTrace();
				        }
				        
				        System.out.println("\nTHE ARCHITECT'S DETAILS\n");
				        
				        try {
				        	
				        	results = statement.executeQuery("SELECT Name, Surname, Telephone, Email_Address, Physical_Address FROM PEOPLE_TABLE WHERE Name = '" + architect.getPersonsName() + "' AND Surname = '" + architect.getPersonsSurname() + "'");
				        	
				        	while (results.next()) {
				        		
				        		System.out.println("Name	" + results.getString("Name") +
				        		"\nSurname		" + results.getString("Surname") +
				        		"\nTelephone		" + results.getString("Telephone") + 
				        		"\nEmail Address		" + results.getString("Emaail_Address") + 
				        		"\nPhysical Address		" + results.getString("Physical_Address"));
				        	}
				        }
				        
				        catch (SQLException ex) {
				        	ex.printStackTrace();
				        }
				        
				        System.out.println("\nTHE CONTRACTOR'S DETAILS\n");
				        
				        try {
				        	
				        	results = statement.executeQuery("SELECT Name, Surname, Telephone, Email_Address, Physical_Address FROM PEOPLE_TABLE WHERE Name = '" + contractor.getPersonsName() + "' AND Surname ='" + contractor.getPersonsSurname() + "'");
				        	
				        	while (results.next()) {
				        		
				        		System.out.println("Name	" + results.getString("Name") +
				        				"\nSurname		" + results.getString("Surname") +
				        				"\nTelephone	" + results.getString("Telephone") +
				        				"\nEmail Address	" + results.getString("Email_Address") +
				        				"\nPhysical Address		" + results.getString("Physical_Address"));
				        	}
				        	
				        }
				        
				        catch (SQLException ex) {
				        	ex.printStackTrace();
				        }

					}
					
					// if the user chooses the 'e' (edit an existing project)
					// the user is given options to choose what part to edit of the existing project
					// once edited, the previous project details are replaced with the new project details in the invoice and project text files
					// which then they are displayed to the user
					else if (optionLower.equals("e")){

				        Boolean editControl = true;
				        
				        while (editControl) {

							System.out.print("\nPlease enter the project number of the project you would like to edit:\n");
							
							Scanner scanner = new Scanner(System.in);
							
							showProjects(projectObject);
						
							int projNum = scanner.nextInt();
							
							ArrayList<PoisedProject> projects = getDataFromPoise();
							
				            String projectNumEdit = "yes";

				            if (projectNumEdit.equals("yes")) {
				            	
				                Scanner input = new Scanner(System.in);
				                
				                System.out.println("\n\nPlease enter the letter of what you would like to edit:\n d - due date,\n a - amount paid,\n u - update contractor,\n f - finalize - ");
				               
				                String choiceEdit = input.nextLine();
				                
				                String choiceEditLower = choiceEdit.toLowerCase();
		 
				                switch (choiceEditLower) {
				            
				                case "d":
				                	
				                    Scanner newDeadline = new Scanner(System.in);
				                    
				                    System.out.print("Please enter the new due date in the form of (dd-MM-yyyy): ");
				                    
				                    String input1 = newDeadline.nextLine();
				                    
				                    projectObject.get(projNum).setProjectDueDate(input1);
				                    
				                    rowsAffected = statement.executeUpdate("UPDATE PROJECT_TABLE SET Project_Duedate = '" + input1 + "' WHERE Project_Number = '" + projNum + "'");
				                    
				                    System.out.println("Query complete, " + rowsAffected + " rows updated.");
				                    
				                    projects.get(projNum).setProjectDueDate(input1);
				                    
				                    System.out.println("\nDUE DATE CHANGED TO : " + projects.get(projNum).getProjectDueDate());

				                    
				                    System.out.print("\nThe new project details\n_______________________________________________________________\n" + projectObject.get(projNum).toString() + "\n_______________________________________________________________\n");
		
				                    editControl = true;
				                   
				                break;
				                    
				                case "a":
				                	
				                    Scanner newPaidAmount = new Scanner(System.in);
				                    
				                    System.out.print("Please enter the new paid amount: R");
				                    
				                    int input2 = newPaidAmount.nextInt();
				                    
				                    rowsAffected = statement.executeUpdate("UPDATE PROJECT_TABLE SET Paid_Amount = " + input2 + "WHERE Project_Number = " + projNum);
				                    
				                    System.out.println("Query complete, " + rowsAffected + " rows updated.");
				                    
				                    projects.get(projNum).setPaidAmount(input2);
				                    
				                    System.out.print("\nThe new project details\n_______________________________________________________________\n" + projectObject.get(projNum).toString() + "\n_______________________________________________________________\n");
		
				                    editControl = true;
			    
				                break;
				                    
				                case "u":
				                	
				                	String contrName = projects.get(projNum).getContractor().getPersonsName();
				                	String contrSurname = projects.get(projNum).getContractor().getPersonsSurname();
				
				                    System.out.print("\nChanging the details of the contractor named: " + projectObject.get(projNum).getContractor().getPersonsName() + " " +projectObject.get(projNum).getContractor().getPersonsSurname() + "\n");
				                    
				                    Scanner newContrNumInput = new Scanner(System.in);
				                    
				                    System.out.print("Please enter their new phone or telephone number: ");
				                    
				                    String newTel = newContrNumInput.nextLine();
				                    
				                    rowsAffected = statement.executeUpdate("UPDATE PEOPLE_TABLE SET Telephone = '" + newTel + "' WHERE Name = '" + contrName + "' AND Surname = '" + contrSurname + "';");

				                    System.out.println("Query complete, " + rowsAffected + " rows updated.");
				                    
				                    Scanner newContrEmailInput = new Scanner(System.in);
				                    
				                    System.out.print("Please enter their new email address: ");
				                    
				                    String newEmail = newContrEmailInput.nextLine();
				                    
				                    rowsAffected = statement.executeUpdate("UPDATE PEOPLE_TABLE SET Email_Address = '" + newEmail + "' WHERE Name = '" + contrName + "' AND Surname = '" + contrSurname + "';");
				                    
				                    System.out.println("Query complete, " + rowsAffected + " rows updated.");
				               
				                    System.out.print("\nThe new details of the contractor\n_______________________________________________________________\n" + projectObject.get(projNum).getContractor().toString() + "\n_______________________________________________________________\n");
				                   
				                    try {
				                    	
				                    	results = statement.executeQuery("SELECT Name, Surname, Telephone, Email_Address, Physical_Address FROM PEOPLE_TABLE WHERE Name = '" + contrName + "' AND Surname = '" + contrSurname + "'");
				                    	
				                    	while (results.next()) {
				                    		
				                    		System.out.println("Name	" + results.getString("Name") +
				                    				"\nSurname		" + results.getString("Surname") +
				                    				"\nTelephone	" + results.getString("Telephone") +
				                    				"\nEmail Address	" + results.getString("Email_Address") + 
				                    				"\nPhysical Address		" + results.getString("Physical_Address"));
				                    	}
				                    }
				                    
				                    catch (SQLException ex) {
				                    	ex.printStackTrace();
				                    }
				                    
				                    editControl = true;
			                break;
				                    
				                case "f":
				                	
				                    if (projectObject.get(projNum).getTotProjectFee() > projectObject.get(projNum).getPaidAmount()) {
				                    	
				                        double balance = projectObject.get(projNum).getTotProjectFee() - projectObject.get(projNum).getPaidAmount();
				                        
				                        System.out.println(balance);
				                        
				                        String invoiceString = "INSERT INTO INVOICE_TABLE VALUES (" + projNum + ", '" +
				                        projects.get(projNum).getClient().getPersonsName() + "', '" + projects.get(projNum).getClient().getPersonsSurname() + 
				                        projects.get(projNum).getTotProjectFee() + ", " + projects.get(projNum).getPaidAmount() + ", " + balance + ");";
				                        
				                        rowsAffected = statement.executeUpdate(invoiceString);
				                        
				                        System.out.println("Query complete, " + rowsAffected + " rows created.");
				                        System.out.println("Invoice saved in the Invoice table.");
				                        
				                    } 
				                    else if (projectObject.get(projNum).getTotProjectFee() <= projectObject.get(projNum).getPaidAmount()) {
				                    	
				                        System.out.println("\nNo invoice to be generated, the client settled the balance.");
				                    }
				                    
				                    Scanner markComplete = new Scanner(System.in);
				                    
				                    System.out.println("\nDo you want to mark this task complete? (Yes or No): ");
				                    
				                    String taskComplete = markComplete.nextLine();
				                    
				                    String taskCompleteLower = taskComplete.toLowerCase();
				                    
				                    if (taskCompleteLower.equals("yes")) {
				                    	
				                    	rowsAffected = statement.executeUpdate("UPDATE PROJECT_TABLE SET Project_Completed = 'Yes' WHERE Project_Number = " + projNum);
				                        
				                    	SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
				                        
				                        String date = sdf.format(new Date());
				                        
				                        rowsAffected = statement.executeUpdate("UPDATE PROJECT_TABLE SET Completion_Date = '" + date + "' WHERE Project_Number =" + projNum);
				                        
				                        System.out.println("Query complete, " + rowsAffected + " rows created.");
				                        
				                        editControl = true;
				                        
				                    	}
					                  }
				                	}
				                   
				                    else if (projectNumEdit.equals("no")) {
				                    	
				                    	System.out.print("\nExit was successful, thank you!");
				                    	
				                    	editControl = true;
				                    	
				                
				                
				                    }
				                    else {
				                    	System.out.println("\nYou have made an invalid option");
			                    }
				            break;
			                    	
				            }
				        
				        writeToFile(projectObject);
				        
					}
				
					// if user chooses 'v' (view incomplete projects)
					// incomplete projects are displayed to the user
					else if(optionLower.equals("v")) {
		                	
		        		System.out.println("\nINCOMPLETE PROJECTS:\n");
		        				
		        		showIncompletedProjects(projectObject);
		        	
					}
				
					// if the user chooses 'o' (overdue projects)
					// overdue projects are displayed to the user
					else if(optionLower.equals("o")) {
		        				
						System.out.println("\nOVERDUE PROJECTS:\n");
		        				
						showPastDueDate(projectObject);
				        
						}
					
					else if (optionLower.equals("p")) {
						
						printAllTasks(statement);
					}
					
					else {
						
						System.out.println("Invalid option.");
					}
				}
			
				// an error exception that will display the message to the user
				catch(Exception error) {
				
					System.out.print("\nError.");
				}
			
			}
			
		}
		
		catch (Exception error) {
			
			System.out.println("Error.");
		}
	}


		
		// this part of the code stored the project details in an Array List
		// which then is to be written in a text file called 'Projects.txt'
		// the information in the text file is displayed if the user chooses to view it
		static ArrayList<PoisedProject> getDataFromFile() {
			
	        ArrayList<String[]> project = new ArrayList<String[]>();
	        
	        ArrayList<PoisedProject> projectObjects= new ArrayList<PoisedProject>();

	    		BufferedReader reader;
	    		
	    		try {
	    			
	    			reader = new BufferedReader(new FileReader("Projects.txt"));
	    			
	    			String line = reader.readLine();
	    			
	    			while (line != null) {
	    				
	    				project.add(line.split(", "));
	    				
	    				
	    				line = reader.readLine();
	    			}
	    			
	    			reader.close();
	    			
	    		} 
	    		catch (IOException e) {
	    			
	    			e.printStackTrace();
	    		}
	    		
	    		
	    		for(int count = 0; count < project.size(); count++) {
	    			
	    			People architect = new People(project.get(count)[15], project.get(count)[16], (project.get(count)[17]), project.get(count)[18], project.get(count)[19]);
	    			
	    			People contractor = new People(project.get(count)[20], project.get(count)[21], (project.get(count)[22]), project.get(count)[23], project.get(count)[24]);
	    			
	    			People client = new People(project.get(count)[10], project.get(count)[11], (project.get(count)[12]), project.get(count)[13], project.get(count)[14]);
	    			
	    			PoisedProject newProject = new PoisedProject(project.get(count)[0], Integer.parseInt(project.get(count)[1]), project.get(count)[2], project.get(count)[3], Integer.parseInt(project.get(count)[4]), Double.parseDouble(project.get(count)[5]), Double.parseDouble(project.get(count)[6]), project.get(count)[7], project.get(count)[8], project.get(count)[9], architect, client, contractor);
	        		
	        		projectObjects.add(newProject);
	    		}
	    		
	    		return projectObjects;
		 }
		
		static void showProjects(ArrayList<PoisedProject> project) {
			
			for(int counter = 0; counter < project.size(); counter++) {
			
				System.out.println(counter+1 + ": " + project.get(counter).getProjectName());
			}
		}
		
		
			static void showIncompletedProjects(ArrayList<PoisedProject> project) {
				
				for(int count = 0; count < project.size(); count++) {
					
					String isComplete = project.get(count).getCompletion();
					
					String isCompleteLower = isComplete.toLowerCase();
					
					if(isCompleteLower.equals("no")) {
						
						System.out.println(count + 1 + "\n"+ project.get(count).toString() + "\n");
					}
				}
			}
			
			static void showPastDueDate(ArrayList<PoisedProject> project) {
				
				for(int counter = 0; counter < project.size(); counter++) {
					
					try {
						
						SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
			            
						String date = sdf.format(new Date());
			            
						Date today;
						
						Date duedate;
						
						today = sdf.parse(date);
						
						duedate = sdf.parse(project.get(counter).getProjectDueDate());
						  
						if(today.compareTo(duedate) > 0){
			
				            System.out.println("The due date for this project is : " + sdf.format(duedate));
				            
				            System.out.println("Today's date is: " + sdf.format(today));
							
				            System.out.println(counter +1 + "\n" + project.get(counter).toString() + "\n");
					}
				}
					
				catch (ParseException e1) {
					
						e1.printStackTrace();
					}
				}
			}
			
	static void writeToFile(ArrayList<PoisedProject> project) {
				
		String line = "";
				
		for(int counter = 0; counter < project.size(); counter++) {
					
		    line = line += project.get(counter).getProjectName() + ", " + project.get(counter).getProjectNum() + ", " + project.get(counter).getBuildingStructure() + ", " + 
				   project.get(counter).getAddress() + ", " + project.get(counter).getERFnum() + ", " + project.get(counter).getTotProjectFee() + ", " + project.get(counter).getPaidAmount() + ", " +
				   project.get(counter).getCompletion() + ", " + project.get(counter).getProjectDueDate() + ", " + project.get(counter).getDateCompleted() + ", " + 
				   project.get(counter).getClient().getPersonsName()  + ", " + project.get(counter).getClient().getPersonsSurname() + ", " + project.get(counter).getClient().getPersonsTelNum() + ", " + 
				   project.get(counter).getClient().getPersonsEmailAddress() + ", " + project.get(counter).getClient().getPersonsAddress() + ", " + project.get(counter).getArchitect().getPersonsName() + ", " + 
				   project.get(counter).getArchitect().getPersonsSurname() + ", " + project.get(counter).getArchitect().getPersonsTelNum() + ", " + project.get(counter).getArchitect().getPersonsEmailAddress() + ", " + 
				   project.get(counter).getArchitect().getPersonsAddress() + ", " + project.get(counter).getContractor().getPersonsName() + ", " + 
				   project.get(counter).getContractor().getPersonsSurname() + ", " + project.get(counter).getContractor().getPersonsTelNum() + ", " + 
				   project.get(counter).getContractor().getPersonsEmailAddress() + ", " + project.get(counter).getContractor().getPersonsAddress()  + "\n";
			}
				
			try {
			    	
				  FileWriter fileWrite = new FileWriter("Projects.txt");
				    
				  fileWrite.write(line);
				    
				  fileWrite.close();
			    	
			} 
			catch(Exception error) {
			    	
				System.out.println(error.getMessage());
		}	
	}
	
	static ArrayList<PoisedProject> getDataFromPoise(){
		
		ArrayList<PoisedProject> projectObjects = new ArrayList<PoisedProject>();
		
		ResultSet results;
		
		try {
			
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?useSSL=false", "otheruser", "SIKHUMBUZOMEMORY@MABASO11!!**!!");
			
			Statement statement = connection.createStatement();
			
			results = statement.executeQuery("SELECT * FROM PROJECT_TABLE");
			
			while (results.next()) {
				
				People client = new People(results.getString("Client_Name"), results.getString("Client_Surname"), null, null, null);
				People architect = new People(results.getString("Architect_Name"), results.getString("Architect_Surname"), null, null, null);
				People contractor = new People(results.getString("Contractor_Name"), results.getString("Contractor_Surname"), null, null, null);
				
				PoisedProject newProject = new PoisedProject(Integer.parseInt(results.getString("Project_Number")),
						results.getString("Project_Name"), results.getString("Building_Type"), results.getString("Project_Address"),
						Integer.parseInt(results.getString("ERF_Number")), Double.parseDouble(results.getString("Project_Fee")), 
						Double.parseDouble(results.getString("Paid_Amount")), results.getString("Project_Duedate"), results.getString("Completion_Date"), client, architect, contractor);
				
				projectObjects.add(newProject);
			}
		}
		
		catch (SQLException ex) {
			ex.printStackTrace();
		}
		
		return projectObjects;
	}
	
	static void printAllTasks(Statement statement) throws SQLException{
		
		ResultSet results;
		
		try {
			
			results = statement.executeQuery("SELECT * FROM PROJECT_TABLE");
			
			System.out.println("\nPOISED PROJECTS:\n");
			
			while (results.next()) {
				
				System.out.println(
						
						"Project Number		" + results.getInt("Project_Number") + 
						"\nProject Name		" + results.getString("Project_Name") + 
						"\nBuilding Type	" + results.getString("Building_Type") +
						"\nProject Address		" + results.getString("Project_Address") +
						"\nERF Number		" + results.getInt("ERF_Number") + 
						"\nProject Fee		" + results.getDouble("Project_Fee") +
						"\nAmount Paid		" + results.getDouble("Paid_Amount") +
						"\nProject Due date		" + results.getString("Project_Duedate") +
						"\nProject Completion		" + results.getString("Project_Completed") +
						"\nCompletion Date		" + results.getString("Completion_Date") + 
						"\nClient Name			" + results.getString("Client_Name") +
						"\nClient Surname		" + results.getString("Client Surname") +
						"\nArchitect Name		" + results.getString("Architect_Name") +
						"\nArchitect Surname		" + results.getString("Architect_Surname") +
						"\nContractor Name		" + results.getString("Contractor_Name") +
						"\nContractor Surname		" + results.getString("Contractor_Surname") + "\n\n"
						
						);
			}
		}
		
		catch (SQLException ex) {
			ex.printStackTrace();
		}
	}
}

